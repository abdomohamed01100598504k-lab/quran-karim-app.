package com.example.qurankareem

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Teal = Color(0xFF176B5D)
private val TealDark = Color(0xFF06483F)
private val Cream = Color(0xFFFFFAF0)
private val Gold = Color(0xFFC5A45D)
private val Ink = Color(0xFF493923)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { QuranApp() }
    }
}

data class AppSection(val title: String, val subtitle: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val sections = listOf(
    AppSection("المصحف الشريف", "قراءة القرآن الكريم وفهرس السور", Icons.Default.MenuBook),
    AppSection("التلاوات الصوتية", "اختر القارئ واستمع للتلاوة", Icons.Default.Headphones),
    AppSection("أسماء الله الحسنى", "99 اسمًا ومعانيها", Icons.Default.AutoAwesome),
    AppSection("تعلم الوضوء والصلاة", "شرح مبسّط وفيديوهات تعليمية", Icons.Default.PlayCircle),
    AppSection("القصص الإسلامية", "قصص القرآن والأنبياء والصحابة", Icons.Default.Book),
    AppSection("مكتبة الأحاديث", "الأحاديث النبوية والقدسية مع المصادر", Icons.Default.LibraryBooks),
    AppSection("الأذكار والتسبيح", "أذكار الصباح والمساء والاستغفار", Icons.Default.Favorite),
    AppSection("الرقية الشرعية", "آيات وأدعية من مصادر موثوقة", Icons.Default.Spa),
    AppSection("قسم الفقه", "الطهارة والصلاة والصيام والمعاملات", Icons.Default.School),
    AppSection("مواقيت الصلاة والأذان", "اضبط المدينة والتنبيهات لاحقًا", Icons.Default.Notifications),
    AppSection("اتجاه القبلة", "إرشادات تحديد القبلة", Icons.Default.Explore),
    AppSection("التقويم الهجري", "تابع التاريخ والمناسبات", Icons.Default.CalendarMonth),
    AppSection("ابنِ جنتك", "تابع أهدافك من الأعمال الصالحة", Icons.Default.Eco),
    AppSection("فضائل السور", "معلومات موثقة عن السور", Icons.Default.Star)
)

private val names = listOf(
    "الرَّحْمَنُ" to "واسع الرحمة لجميع الخلق",
    "الرَّحِيمُ" to "كثير الرحمة بعباده المؤمنين",
    "الْمَلِكُ" to "المالك المتصرف في خلقه",
    "الْقُدُّوسُ" to "المنزّه عن كل نقص",
    "السَّلَامُ" to "السالم من كل عيب ونقص",
    "الْمُؤْمِنُ" to "الذي يؤمّن عباده ويصدق وعده",
    "الْمُهَيْمِنُ" to "الرقيب الحافظ على كل شيء",
    "الْعَزِيزُ" to "الغالب الذي لا يُغلب",
    "الْجَبَّارُ" to "العالي القاهر وجابر الكسير",
    "الْمُتَكَبِّرُ" to "المتعالي عن صفات الخلق"
)

private val adhkar = listOf(
    "أستغفر الله" ,
    "سبحان الله وبحمده",
    "لا إله إلا الله وحده لا شريك له، له الملك وله الحمد",
    "لا إله إلا الله العلي العظيم",
    "أستغفر الله الذي لا إله إلا هو الحي القيوم وأتوب إليه",
    "لا إله إلا الله والله أكبر ولا حول ولا قوة إلا بالله",
    "سبحان الله",
    "سبحان الله وبحمده، عدد خلقه ورضا نفسه وزنة عرشه",
    "الله أكبر كبيرًا والحمد لله كثيرًا وسبحان الله بكرة وأصيلًا",
    "الصلاة على النبي ﷺ"
)

@Composable
fun QuranApp() {
    var selectedTab by remember { mutableStateOf("الرئيسية") }
    var selectedSection by remember { mutableStateOf<AppSection?>(null) }
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Teal, onPrimary = Color.White, secondary = Gold,
            background = Cream, surface = Color.White, onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = Cream,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf(
                        "الرئيسية" to Icons.Default.Home,
                        "القرآن" to Icons.Default.MenuBook,
                        "الأذكار" to Icons.Default.Favorite,
                        "المزيد" to Icons.Default.GridView
                    ).forEach { (label, icon) ->
                        NavigationBarItem(
                            selected = selectedTab == label,
                            onClick = { selectedTab = label; selectedSection = null },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { padding ->
            if (selectedSection != null) {
                SectionScreen(selectedSection!!, Modifier.padding(padding)) { selectedSection = null }
            } else when (selectedTab) {
                "القرآن" -> SectionScreen(sections[0], Modifier.padding(padding)) { selectedTab = "الرئيسية" }
                "الأذكار" -> SectionScreen(sections[6], Modifier.padding(padding)) { selectedTab = "الرئيسية" }
                "المزيد" -> HomeScreen(Modifier.padding(padding), onOpen = { selectedSection = it }, showAll = true)
                else -> HomeScreen(Modifier.padding(padding), onOpen = { selectedSection = it }, showAll = false)
            }
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier = Modifier, onOpen: (AppSection) -> Unit, showAll: Boolean) {
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("بسم الله الرحمن الرحيم", color = Teal, fontSize = 14.sp)
                    Text("القرآن الكريم", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text("رفيقك اليومي للقرآن والعبادة والمعرفة", color = Ink.copy(alpha = .7f), fontSize = 13.sp)
                }
                Box(Modifier.size(56.dp).background(TealDark, CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.MenuBook, null, tint = Gold, modifier = Modifier.size(32.dp))
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = TealDark), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("﴿ إِنَّ هَٰذَا الْقُرْآنَ يَهْدِي لِلَّتِي هِيَ أَقْوَمُ ﴾", color = Color.White, fontSize = 18.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(8.dp))
                    Text("الإسراء: ٩", color = Gold)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { onOpen(sections[0]) }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) {
                        Text("افتح المصحف", color = TealDark, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item {
            Text(if (showAll) "جميع الأقسام" else "استكشف الأقسام", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
        }
        items(if (showAll) sections else sections.take(8)) { section ->
            SectionCard(section) { onOpen(section) }
        }
        item {
            Text("المحتوى الديني سيُربط بمصادر موثوقة مع مراجعة النصوص والتراخيص قبل النشر.", color = Ink.copy(alpha = .65f), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(8.dp))
        }
    }
}

@Composable
fun SectionCard(section: AppSection, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(50.dp).background(Color(0xFFE2F3F0), CircleShape), contentAlignment = Alignment.Center) {
                Icon(section.icon, null, tint = Teal, modifier = Modifier.size(27.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(section.title, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Ink)
                Spacer(Modifier.height(3.dp))
                Text(section.subtitle, fontSize = 12.sp, color = Ink.copy(alpha = .65f))
            }
            Icon(Icons.Default.ChevronLeft, null, tint = Gold)
        }
    }
}

@Composable
fun SectionScreen(section: AppSection, modifier: Modifier = Modifier, onBack: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val counters = remember { mutableStateMapOf<String, Int>() }
    Column(modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(TealDark).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowForward, "رجوع", tint = Color.White) }
            Column(Modifier.weight(1f)) {
                Text(section.title, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text(section.subtitle, color = Color.White.copy(alpha = .8f), fontSize = 12.sp)
            }
            Icon(section.icon, null, tint = Gold, modifier = Modifier.size(28.dp))
        }
        when {
            section.title == "أسماء الله الحسنى" -> {
                OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("ابحث في الأسماء") }, modifier = Modifier.fillMaxWidth().padding(12.dp), singleLine = true)
                LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(names.filter { it.first.contains(query) || it.second.contains(query) }) { (name, meaning) ->
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(name, modifier = Modifier.weight(1f), color = Teal, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                Text(meaning, modifier = Modifier.weight(1.2f), textAlign = TextAlign.End, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
            section.title.contains("الأذكار") || section.title == "الرقية الشرعية" -> {
                val list = if (section.title == "الرقية الشرعية") listOf(
                    "الرقية الشرعية من القرآن والسنة",
                    "رقية السحر — نصوص شرعية موثقة",
                    "رقية العين والحسد",
                    "أدعية التحصين المأثورة",
                    "تلاوات صوتية: تُضاف بعد التحقق من المصدر والترخيص"
                ) else adhkar
                LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(list) { text ->
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                                Text(text, fontSize = 17.sp, color = Ink)
                                if (section.title != "الرقية الشرعية") {
                                    Spacer(Modifier.height(8.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("العدد: ${counters[text] ?: 0}", color = Teal, modifier = Modifier.weight(1f))
                                        FilledTonalButton(onClick = { counters[text] = (counters[text] ?: 0) + 1 }) { Text("تسبيح +1") }
                                        TextButton(onClick = { counters[text] = 0 }) { Text("تصفير") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            section.title == "المصحف الشريف" -> {
                Column(Modifier.fillMaxSize().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("المصحف الشريف", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Teal)
                    Text("سورة الفاتحة", fontSize = 22.sp, color = Gold, fontWeight = FontWeight.Bold)
                    Text("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nالْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ\nالرَّحْمَٰنِ الرَّحِيمِ\nمَالِكِ يَوْمِ الدِّينِ\nإِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ\nاهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ\nصِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ", fontSize = 24.sp, lineHeight = 44.sp, textAlign = TextAlign.Center, color = Ink)
                    Text("نسخة أولية: سنربط المصحف الكامل بمصدر نصي موثوق بعد التحقق من الترخيص.", fontSize = 12.sp, color = Ink.copy(alpha = .65f), textAlign = TextAlign.Center)
                }
            }
            else -> {
                LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                                Text("هذه شاشة أولية لقسم ${section.title}", fontWeight = FontWeight.Bold, fontSize = 19.sp, color = Teal)
                                Spacer(Modifier.height(8.dp))
                                Text("سيتم إضافة المحتوى الكامل والبحث والمفضلة والعمل دون إنترنت في مراحل التنفيذ التالية.", color = Ink)
                            }
                        }
                    }
                    items(listOf("المحتوى الموثوق", "المفضلة", "التنزيل للاستخدام دون إنترنت")) { item ->
                        ListItem(headlineContent = { Text(item) }, leadingContent = { Icon(Icons.Default.CheckCircle, null, tint = Teal) })
                    }
                }
            }
        }
    }
}
